"""App package initializer."""
