DB_TYPE = "mssql"

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "spms_db"
}

MSSQL_CONFIG = {
    "server": r"DESKTOP-69ATCUG\SQLEXPRESS",
    "database": "SPMS_DB",
    "trusted": True,
    "user": "",
    "password": "",
    "driver": "ODBC Driver 18 for SQL Server"
}
