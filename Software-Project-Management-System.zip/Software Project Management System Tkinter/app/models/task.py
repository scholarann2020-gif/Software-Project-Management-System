class Task:
    def __init__(self, task_id, title, status):
        self.id = task_id
        self.title = title
        self.status = status
