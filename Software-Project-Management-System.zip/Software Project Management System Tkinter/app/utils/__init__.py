"""Utilities package for the SPMS application."""
