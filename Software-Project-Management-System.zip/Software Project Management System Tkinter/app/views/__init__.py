"""Views package for the SPMS application."""
